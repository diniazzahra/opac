<?php

namespace App\Http\Controllers\Api;

use Illuminate\Routing\Controller;

class ApiApp extends Controller
{

}
