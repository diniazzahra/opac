<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('driver')->comment('Penyedia')->nullable();
            $table->string('username')->comment('user id pada penyedia')->nullable();
            $table->string('name')->comment('Nama user')->nullable();
            $table->string('email')->unique()->comment('Email')->nullable();
            $table->string('photo')->nullable()->comment('Photo profil');
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->useCurrent();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
