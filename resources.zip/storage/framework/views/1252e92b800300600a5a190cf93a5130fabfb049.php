<?php
/**
 * Created by Pizaini <pizaini@uin-suska.ac.id>
 * Date: 20/01/2019
 * Time: 22:29
 */
?>
<section class="app-placeholder section text-center pt-5 d-none">
    <div class="spinner-grow text-danger m-2" role="status">
        <span class="sr-only">Loading...</span>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\faraby\resources\views/partials/placeholder.blade.php ENDPATH**/ ?>