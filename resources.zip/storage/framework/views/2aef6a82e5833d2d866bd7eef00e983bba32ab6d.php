<?php
/**
 * Created by Pizaini <pizaini@uin-suska.ac.id>
 * Date: 26/04/2019
 * Time: 15:08
 */
?>
<!-- Footer Start -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                2019 - <?=date('Y')?> &copy; FarabyApp v<?php echo e(config('app.version')); ?> by <a href="https://www.digistlab.com" target="_blank">Digistlab</a>
            </div>
            <div class="col-md-6">
                <div class="text-md-right footer-links d-none d-sm-block">
                    <a href="javascript:void(0);">About Us</a>
                    <a href="javascript:void(0);">Help</a>
                    <a href="javascript:void(0);">Contact Us</a>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- end Footer -->
<?php /**PATH C:\xampp\htdocs\faraby\resources\views/partials/footer.blade.php ENDPATH**/ ?>