<?php
/**
 * Created by Pizaini <pizaini@uin-suska.ac.id>
 * Date: 19/12/2019
 * Time: 19:03
 */
?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex">
    <meta name="googlebot" content="noindex">
    <meta name="description" content="<?php echo e(config('app.name_long')); ?>">
    <meta name="keywords" content="<?php echo e(config('app.keywords')); ?>">
    <meta name="author" content="<?php echo e(config('app.author')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', config('app.name')); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>">
    <!-- CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('adminto/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('adminto/css/icons.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('adminto/css/app.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap-vue.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/placeholder-loading.min.css')); ?>">
    <!-- JS-->
    <script type="text/javascript" src="<?php echo e(asset('js/vue.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/bootstrap-vue.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery-3.4.1.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/pjax.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/app-custom.js')); ?>"></script>
</head>
<body class="drop-menu-dark unsticky-header enlarged">
<!-- Pre-loader -->
<div id="preloader">
    <div id="status">
        <div class="spinner-grow text-success m-2" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
</div>
<!-- End Preloader-->
<!-- Navigation Bar-->
<header id="topnav">
    <?php echo $__env->make('partials.topnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.topmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</header>
<!-- End Navigation Bar-->
    <?php echo $__env->yieldContent('main_content'); ?>
    <!-- paceholder -->
    <div class="wrapper">
        <div class="container-fluid">
            <?php echo $__env->make('partials.placeholder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script type="text/javascript" src="<?php echo e(asset('adminto/js/vendor.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('adminto/js/app.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/vee-validate/id.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery.serializeToJSON.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\faraby\resources\views/layouts/horizontal.blade.php ENDPATH**/ ?>