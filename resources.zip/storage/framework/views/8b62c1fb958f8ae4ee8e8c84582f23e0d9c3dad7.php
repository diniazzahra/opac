<?php
/**
 * Created by Pizaini <pizaini@uin-suska.ac.id>
 * Date: 19/12/2019
 * Time: 21:14
 *
 * @var array $breadcrumbs
 */

$data = $breadcrumbs ?? [];
?>
<div class="page-title-right">
    <ol class="breadcrumb m-0">
        <li class="breadcrumb-item"><b-link href="<?php echo e(route('home')); ?>">Home</b-link></li>
        <?php if($data ?? ''): ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="breadcrumb-item active"><?=$title?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </ol>
</div>
<?php /**PATH C:\xampp\htdocs\faraby\resources\views/partials/breadcrumb.blade.php ENDPATH**/ ?>