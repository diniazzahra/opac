<?php
/**
 * Created by Pizaini <pizaini@uin-suska.ac.id>
 * Date: 19/12/2019
 * Time: 19:03
 */
?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex">
    <meta name="googlebot" content="noindex">
    <meta name="description" content="<?php echo e(config('app.name_long')); ?>">
    <meta name="keywords" content="<?php echo e(config('app.keywords')); ?>">
    <meta name="author" content="<?php echo e(config('app.author')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', config('app.name')); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>">
    <!-- CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('adminto/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('adminto/css/icons.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('adminto/css/app.min.css')); ?>">
</head>
<body class="authentication-bg">
<div id="preloader">
    <div id="status">
        <div id="status">
            <div class="spinner-border text-info m-2" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->yieldContent('body'); ?>

<?php echo $__env->make('partials.footer_large', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Vendor js -->
<script src="<?php echo e(asset('adminto/js/vendor.min.js')); ?>"></script>

<script src="<?php echo e(asset('adminto/js/app.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\faraby\resources\views/layouts/main.blade.php ENDPATH**/ ?>