<?php
/**
 * Created by Pizaini <pizaini@uin-suska.ac.id>
 * Date: 14/01/2020
 * Time: 21:24
 */
?>
<footer class="footer" style="left: 0px !important;">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                2019 - <?=date('Y')?>  &copy; FarabyApp v{{config('app.version')}} by <a href="https://www.digistlab.com" target="_blank">Digistlab</a>
            </div>
            <div class="col-md-6">
                <div class="text-md-right footer-links d-none d-sm-block">
                    <a href="javascript:void(0);">About Us</a>
                    <a href="javascript:void(0);">Help</a>
                    <a href="javascript:void(0);">Contact Us</a>
                </div>
            </div>
        </div>
    </div>
</footer>
